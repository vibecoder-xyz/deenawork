"""Builds a single self-contained preview file from this project: python3 build_single.py"""
import base64,re,pathlib
r=pathlib.Path(__file__).parent
h=(r/'index.html').read_text()
h=h.replace('<link rel="stylesheet" href="css/styles.css">','<style>'+(r/'css/styles.css').read_text()+'</style>')
h=h.replace('<script src="js/main.js"></script>','<script>'+(r/'js/main.js').read_text()+'</script>')
def uri(m):
    p=r/m.group(1); t={'jpg':'image/jpeg','webp':'image/webp','svg':'image/svg+xml'}[p.suffix[1:]]
    return 'src="data:%s;base64,%s"'%(t,base64.b64encode(p.read_bytes()).decode()) if m.group(0).startswith('src') else 'href="data:%s;base64,%s"'%(t,base64.b64encode(p.read_bytes()).decode())
h=re.sub(r'(?:src|href)="(assets/[^"]+)"',uri,h)
(r/'deena-preview.html').write_text(h); print(len(h)//1024,'KB')
