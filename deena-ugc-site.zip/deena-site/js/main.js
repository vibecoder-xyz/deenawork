(function(){
  var d=document,b=d.body,burger=d.getElementById('burger');
  function close(){b.classList.remove('menu-open');burger.setAttribute('aria-expanded','false')}
  burger.addEventListener('click',function(){var o=b.classList.toggle('menu-open');burger.setAttribute('aria-expanded',o)});
  d.querySelectorAll('.nav a').forEach(function(a){a.addEventListener('click',close)});
  var reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;

  function count(el){var n=+el.dataset.n,t=0;(function s(){t+=1/45;el.textContent=Math.round(n*Math.min(t,1))+'+';if(t<1)requestAnimationFrame(s)})()}
  var io=new IntersectionObserver(function(es){es.forEach(function(e){
    if(!e.isIntersecting)return;e.target.classList.add('in');
    e.target.querySelectorAll('[data-n]').forEach(count);io.unobserve(e.target)})},{threshold:.2});
  d.querySelectorAll('.rv').forEach(function(el,i){el.style.transitionDelay=(i%4)*80+'ms';io.observe(el)});

  var title=d.getElementById('title');
  if(!reduce)addEventListener('scroll',function(){var y=scrollY;if(y<innerHeight)title.style.transform='translateY('+y*.18+'px)'},{passive:true});
})();
